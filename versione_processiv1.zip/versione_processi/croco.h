#pragma once
#include <ncurses.h>

void cocco(int nC,int pipefd, int y);
void stampCocco(int numCroco,int pipefd,int positions[]);